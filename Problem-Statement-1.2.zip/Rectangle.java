package CoreJava;

import java.util.Scanner;

public class Rectangle {
	    int length; 
	    int breadth; 
	    int area; 
	   
	    public Rectangle()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length : ");
	        length = in.nextInt();
	        System.out.print("Enter breadth : ");
	        breadth = in.nextInt();
	    }

	    void calculate() {
	        area = length * breadth;	        
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	       
	    }

	    public static void main(String args[]) {
	        Rectangle r1 = new Rectangle();
	        r1.input();
	        r1.calculate();
	        r1.display();
	        System.out.println("--------");
	        Rectangle r2 = new Rectangle();
	        r2.input();
	        r2.calculate();
	        r2.display();
	        System.out.println("--------");
	        Rectangle r3 = new Rectangle();
	        r3.input();
	        r3.calculate();
	        r3.display();
	        System.out.println("--------");
	        Rectangle r4 = new Rectangle();
	        r4.input();
	        r4.calculate();
	        r4.display();
	    }
	}
