package CoreJava;

import java.util.Scanner;
public class TextBook
{
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Book1 :");
        String bookname=sc.nextLine();
        System.out.println("Enter the Book2 :");
        String bookname1=sc.nextLine();
        
        System.out.println("Enter price:");
        int price=sc.nextInt();
        System.out.println("Enter price:");
        int price1=sc.nextInt();
        sc.nextLine();
        
        
        Book obj=new Book();
        obj.setBookName(bookname);
        obj.setBookPrice(price);
        
        Book obj1=new Book();
        obj1.setBookName(bookname1);
        obj1.setBookPrice(price1);
        
        System.out.println("Book Title ");
        System.out.println("Book Name :"+obj.getBookName());
        System.out.println("Book Price :RS."+obj.getBookPrice());
        System.out.println("Book Name :"+obj1.getBookName());
        System.out.println("Book Price :RS."+obj1.getBookPrice());
       
    }
}

