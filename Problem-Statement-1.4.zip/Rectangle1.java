package CoreJava;

import java.util.Scanner;

public class Rectangle1 {
	    int length; 
	    int width; 
	    int area; 
	    int parameter;
	    
	    public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		
	    public Rectangle1()
	    {
	    	length = 1;
	    	width= 1;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length : ");
	        length = in.nextInt();
	        System.out.print("Enter width : ");
	        width = in.nextInt();
	    }
	    
	    void  areaRectangle1()
	    {
	        area = length * width;
	       
	    }
	 
	     void  perimeterRectangle1()
	    {
	    	 parameter = 2*(length + width);
	       
	    }

	    void display() {
	    	if(length>0 && length<20)
	    		if(width>0 && width<20)
	        {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Perimeter of Rectangle = " +parameter);}
	       
	        }
	    	
	    

	    public static void main(String args[]) {
	    	
	        Rectangle1 r1 = new Rectangle1();
	        r1.input();
	        r1.areaRectangle1();
	        r1.perimeterRectangle1();
	        r1.display();
	        System.out.println("-------");
	        Rectangle1 r2 = new Rectangle1();
	        r2.input();
	        r2.areaRectangle1();
	        r2.perimeterRectangle1();
	        r2.display();
	        System.out.println("-------");
	        Rectangle1 r3 = new Rectangle1();
	        r3.input();
	        r3.areaRectangle1();
	        r3.perimeterRectangle1();
	        r3.display();
	        System.out.println("-------");
	        Rectangle1 r4 = new Rectangle1();
	        r4.input();
	        r4.areaRectangle1();
	        r4.perimeterRectangle1();
	        r4.display();	    	
	    }
	}